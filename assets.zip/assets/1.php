<?php

// Klasörünüzün yolu
$klasor_yolu = 'fol';

// Klasördeki tüm dosyaları al
$dosyalar = scandir($klasor_yolu);

// Dosyaları tek tek kontrol et
foreach ($dosyalar as $dosya) {
    // Sadece dosya olduğundan emin ol
    if (is_file($klasor_yolu . '/' . $dosya)) {
        // Dosyayı oku
        $dosya_icerik = file_get_contents($klasor_yolu . '/' . $dosya);

        // -original-wordmark metnini sil
        $duzenlenmis_icerik = str_replace('-original', '', $dosya_icerik);

        // Dosyayı yeniden yaz
        file_put_contents($klasor_yolu . '/' . $dosya, $duzenlenmis_icerik);

        // Yeniden adlandırma işlemi
        $yeni_dosya_adi = str_replace('-original', '', $dosya);
        rename($klasor_yolu . '/' . $dosya, $klasor_yolu . '/' . $yeni_dosya_adi);

        echo "Dosya '$dosya' düzenlendi ve adı değiştirildi.\n";
    }
}

echo "İşlem tamamlandı.";
?>
