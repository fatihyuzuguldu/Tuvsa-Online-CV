#! /bin/sh

make jshint test
